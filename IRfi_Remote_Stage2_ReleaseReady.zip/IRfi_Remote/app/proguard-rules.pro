# IRfi Remote ProGuard rules
