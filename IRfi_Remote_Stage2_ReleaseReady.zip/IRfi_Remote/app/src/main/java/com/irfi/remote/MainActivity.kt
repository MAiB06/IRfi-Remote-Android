package com.irfi.remote

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.irfi.remote.ui.IRfiApp
import com.irfi.remote.ui.theme.IRfiTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            IRfiTheme {
                IRfiApp()
            }
        }
    }
}
