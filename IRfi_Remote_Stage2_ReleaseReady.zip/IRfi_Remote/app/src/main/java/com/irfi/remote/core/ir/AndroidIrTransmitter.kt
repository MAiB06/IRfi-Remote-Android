package com.irfi.remote.core.ir

import android.content.Context
import android.hardware.ConsumerIrManager

data class IrCapability(
    val available: Boolean,
    val carrierRanges: List<CarrierRange>,
    val message: String
)

class AndroidIrTransmitter(context: Context) {
    private val manager = context.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager

    fun capability(): IrCapability {
        if (manager == null) return IrCapability(false, emptyList(), "Consumer IR service is unavailable on this device.")
        if (!manager.hasIrEmitter()) return IrCapability(false, emptyList(), "No IR emitter was reported by Android.")
        val ranges = try {
            manager.carrierFrequencies?.map { CarrierRange(it.minFrequency, it.maxFrequency) } ?: emptyList()
        } catch (_: Exception) { emptyList() }
        return IrCapability(true, ranges, if (ranges.isEmpty()) "IR emitter detected; frequency ranges unavailable." else "IR emitter detected.")
    }

    fun transmit(frequencyHz: Int, pattern: IntArray): Result<Unit> = runCatching {
        require(manager != null && manager.hasIrEmitter()) { "IR emitter is unavailable." }
        require(frequencyHz in 20_000..60_000) { "Carrier frequency must be between 20,000 and 60,000 Hz." }
        require(pattern.size >= 2) { "IR pattern must contain at least two timings." }
        require(pattern.size <= 500) { "IR pattern is too long (maximum 500 timings)." }
        require(pattern.all { it in 1..100_000 }) { "Each timing must be between 1 and 100,000 microseconds." }
        val ranges = manager.carrierFrequencies
        if (ranges != null && ranges.isNotEmpty()) {
            require(ranges.any { frequencyHz in it.minFrequency..it.maxFrequency }) {
                "The selected frequency is outside this phone's reported supported ranges."
            }
        }
        manager.transmit(frequencyHz, pattern)
    }
}
