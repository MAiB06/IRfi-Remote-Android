package com.irfi.remote.data.model

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class SavedIrCommand(
    val name: String,
    val frequencyHz: Int,
    val pattern: IntArray
)

class IrProfileStore(context: Context) {
    private val prefs = context.getSharedPreferences("irfi_profiles", Context.MODE_PRIVATE)

    fun getProfileNames(): List<String> =
        prefs.getStringSet("profiles", setOf("Elista TV", "HomeTV"))?.toList()?.sorted()
            ?: listOf("Elista TV", "HomeTV")

    fun addProfile(name: String) {
        val clean = name.trim()
        require(clean.isNotEmpty()) { "Profile name cannot be empty." }
        val names = getProfileNames().toMutableSet().apply { add(clean) }
        prefs.edit().putStringSet("profiles", names).apply()
    }

    fun saveCommand(profile: String, command: SavedIrCommand) {
        val key = "commands_" + profile
        val array = JSONArray(prefs.getString(key, "[]"))
        val updated = JSONArray()
        for (i in 0 until array.length()) {
            val item = array.getJSONObject(i)
            if (!item.getString("name").equals(command.name, ignoreCase = true)) updated.put(item)
        }
        val timings = JSONArray()
        command.pattern.forEach { timings.put(it) }
        updated.put(JSONObject().put("name", command.name).put("frequency", command.frequencyHz).put("pattern", timings))
        prefs.edit().putString(key, updated.toString()).apply()
    }

    fun getCommands(profile: String): List<SavedIrCommand> {
        val array = JSONArray(prefs.getString("commands_" + profile, "[]"))
        return (0 until array.length()).mapNotNull { i ->
            runCatching {
                val item = array.getJSONObject(i)
                val timings = item.getJSONArray("pattern")
                SavedIrCommand(item.getString("name"), item.getInt("frequency"),
                    IntArray(timings.length()) { timings.getInt(it) })
            }.getOrNull()
        }
    }

    fun removeCommand(profile: String, name: String) {
        val old = JSONArray(prefs.getString("commands_" + profile, "[]"))
        val updated = JSONArray()
        for (i in 0 until old.length()) {
            val item = old.getJSONObject(i)
            if (!item.getString("name").equals(name, ignoreCase = true)) updated.put(item)
        }
        prefs.edit().putString("commands_" + profile, updated.toString()).apply()
    }
}
