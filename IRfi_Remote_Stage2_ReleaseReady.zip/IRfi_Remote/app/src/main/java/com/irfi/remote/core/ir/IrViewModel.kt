package com.irfi.remote.core.ir

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.irfi.remote.data.model.IrProfileStore
import com.irfi.remote.data.model.SavedIrCommand
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class IrUiState(
    val available: Boolean = false,
    val status: String = "Checking IR hardware…",
    val ranges: List<CarrierRange> = emptyList(),
    val selectedProfile: String = "Elista TV",
    val profiles: List<String> = listOf("Elista TV", "HomeTV"),
    val commands: List<SavedIrCommand> = emptyList(),
    val lastResult: String = ""
)

class IrViewModel(app: Application) : AndroidViewModel(app) {
    private val transmitter = AndroidIrTransmitter(app)
    private val store = IrProfileStore(app)
    private val _state = MutableStateFlow(IrUiState())
    val state: StateFlow<IrUiState> = _state.asStateFlow()

    init { refresh() }

    fun refresh() {
        val cap = transmitter.capability()
        val profiles = store.getProfileNames()
        val selected = _state.value.selectedProfile.takeIf { it in profiles } ?: profiles.firstOrNull() ?: "Elista TV"
        _state.value = _state.value.copy(
            available = cap.available, status = cap.message, ranges = cap.carrierRanges,
            profiles = profiles, selectedProfile = selected,
            commands = store.getCommands(selected)
        )
    }

    fun selectProfile(name: String) {
        _state.value = _state.value.copy(selectedProfile = name, commands = store.getCommands(name), lastResult = "")
    }

    fun addProfile(name: String): Result<Unit> = runCatching {
        store.addProfile(name)
        refresh()
    }

    fun saveCommand(name: String, frequency: Int, patternText: String): Result<Unit> = runCatching {
        val values = patternText.split(",", " ", "\n", "\t").filter { it.isNotBlank() }.map { it.trim().toInt() }
        require(values.size >= 2) { "Enter at least two comma-separated timing values." }
        store.saveCommand(_state.value.selectedProfile, SavedIrCommand(name.trim(), frequency, values.toIntArray()))
        refresh()
    }

    fun send(command: SavedIrCommand) {
        val result = transmitter.transmit(command.frequencyHz, command.pattern)
        _state.value = _state.value.copy(lastResult = result.fold(
            { "Sent ${command.name} at ${command.frequencyHz} Hz." },
            { "Transmission failed: ${it.message ?: "Unknown error"}" }
        ))
    }

    fun removeCommand(name: String) {
        store.removeCommand(_state.value.selectedProfile, name)
        refresh()
    }
}
