package com.irfi.remote.core.ir

data class IrHardwareStatus(
    val hasEmitter: Boolean,
    val supportedCarrierRanges: List<CarrierRange>
)

data class CarrierRange(
    val minimumHz: Int,
    val maximumHz: Int
)
