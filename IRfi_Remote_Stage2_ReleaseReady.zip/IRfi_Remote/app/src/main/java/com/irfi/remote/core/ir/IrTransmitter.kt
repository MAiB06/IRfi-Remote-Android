package com.irfi.remote.core.ir

import com.irfi.remote.data.model.RemoteCommand

/**
 * Transport contract for Stage 2.
 * A concrete Android ConsumerIrManager implementation will be added and tested
 * against the OnePlus 15 before any command is shown as working.
 */
interface IrTransmitter {
    fun hardwareStatus(): IrHardwareStatus
    fun transmit(command: RemoteCommand, profileId: String): Result<Unit>
}
