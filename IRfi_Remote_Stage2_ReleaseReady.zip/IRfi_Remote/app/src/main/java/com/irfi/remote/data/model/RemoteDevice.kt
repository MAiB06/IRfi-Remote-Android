package com.irfi.remote.data.model

enum class ConnectionTransport {
    IR, WIFI, BLUETOOTH
}

data class RemoteDevice(
    val id: String,
    val name: String,
    val manufacturer: String? = null,
    val model: String? = null,
    val preferredTransport: ConnectionTransport = ConnectionTransport.IR,
    val hasIrProfile: Boolean = false
)
