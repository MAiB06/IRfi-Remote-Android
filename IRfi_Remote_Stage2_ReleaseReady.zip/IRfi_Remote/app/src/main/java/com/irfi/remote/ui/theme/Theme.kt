package com.irfi.remote.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val OnePlusDark = darkColorScheme(
    primary = Color(0xFFB6C7FF),
    onPrimary = Color(0xFF102D60),
    secondary = Color(0xFFBFC7DC),
    tertiary = Color(0xFFE4B9D2),
    background = Color(0xFF101114),
    surface = Color(0xFF17191E),
    surfaceVariant = Color(0xFF424650)
)

private val OnePlusLight = lightColorScheme(
    primary = Color(0xFF315DA8),
    secondary = Color(0xFF555F76),
    tertiary = Color(0xFF76536D)
)

@Composable
fun IRfiTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    MaterialTheme(
        colorScheme = if (dark) OnePlusDark else OnePlusLight,
        typography = MaterialTheme.typography,
        content = content
    )
}
