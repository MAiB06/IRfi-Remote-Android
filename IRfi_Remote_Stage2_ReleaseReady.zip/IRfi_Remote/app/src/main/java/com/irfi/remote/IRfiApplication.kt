package com.irfi.remote

import android.app.Application

class IRfiApplication : Application()
