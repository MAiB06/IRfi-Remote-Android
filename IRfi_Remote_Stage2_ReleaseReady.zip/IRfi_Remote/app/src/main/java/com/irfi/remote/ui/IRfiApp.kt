package com.irfi.remote.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.irfi.remote.core.ir.IrViewModel
import com.irfi.remote.data.model.SavedIrCommand

private enum class Destination(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    HOME("Home", Icons.Default.Home), REMOTE("Remote", Icons.Default.Tv),
    INPUT("Input", Icons.Default.Keyboard), TOOLS("Tools", Icons.Default.Tune),
    SETTINGS("Settings", Icons.Default.Settings)
}

@Composable
fun IRfiApp() {
    var selected by remember { mutableStateOf(Destination.HOME) }
    val vm: IrViewModel = viewModel()
    val state by vm.state.collectAsState()
    Scaffold(bottomBar = {
        NavigationBar {
            Destination.entries.forEach { d ->
                NavigationBarItem(selected == d, { selected = d },
                    icon = { Icon(d.icon, d.label) }, label = { Text(d.label) })
            }
        }
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).background(MaterialTheme.colorScheme.background)) {
            when (selected) {
                Destination.HOME -> HomeScreen(state.selectedProfile, state.profiles, state.status, state.available,
                    onSelect = { vm.selectProfile(it); selected = Destination.REMOTE },
                    onAdd = { selected = Destination.SETTINGS })
                Destination.REMOTE -> RemoteScreen(state.selectedProfile, state.commands, vm::send, state.lastResult)
                Destination.INPUT -> InputScreen()
                Destination.TOOLS -> ToolsScreen(state.commands, vm::send, vm::removeCommand)
                Destination.SETTINGS -> SettingsScreen(
                    status = state.status, available = state.available, ranges = state.ranges,
                    profiles = state.profiles, selected = state.selectedProfile,
                    onSelect = vm::selectProfile, onAddProfile = vm::addProfile,
                    onRefresh = vm::refresh, onSave = vm::saveCommand
                )
            }
        }
    }
}

@Composable
private fun HomeScreen(active: String, profiles: List<String>, status: String, available: Boolean,
                       onSelect: (String) -> Unit, onAdd: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("IRfi Remote", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text("Your televisions", color = MaterialTheme.colorScheme.onSurfaceVariant)
        ElevatedCard(Modifier.fillMaxWidth()) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(if (available) Icons.Default.CheckCircle else Icons.Default.Warning, null,
                    tint = if (available) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(if (available) "IR hardware detected" else "IR hardware unavailable")
                    Text(status, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        Text("DEVICE PROFILES", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
        profiles.forEach { name ->
            ElevatedCard(Modifier.fillMaxWidth().clickable { onSelect(name) }) {
                Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Tv, null)
                    Spacer(Modifier.width(16.dp))
                    Text(name, Modifier.weight(1f), style = MaterialTheme.typography.titleLarge)
                    if (name == active) Icon(Icons.Default.Check, "Selected")
                    Icon(Icons.Default.ChevronRight, null)
                }
            }
        }
        OutlinedButton(onClick = onAdd, Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Text("Manage profiles and IR codes") }
    }
}

@Composable
private fun RemoteScreen(profile: String, commands: List<SavedIrCommand>,
                         send: (SavedIrCommand) -> Unit, result: String) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(profile, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Saved IR commands", color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (commands.isEmpty()) {
            Text("No IR codes configured yet. Add verified codes in Settings → IR code manager.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(commands, key = { it.name }) { command ->
                    FilledTonalButton(onClick = { send(command) }, Modifier.fillMaxWidth()) {
                        Text(command.name)
                    }
                }
            }
        }
        if (result.isNotBlank()) Text(result, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun InputScreen() {
    var text by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Input", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text("This is a local typing preview. TV keyboard delivery requires a compatible network or HID protocol.")
        OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), label = { Text("Typing preview") }, minLines = 2)
        OutlinedButton(onClick = { text = "" }) { Text("Clear") }
        Text("Touchpad and TV text input are not implemented in this IR stage.")
    }
}

@Composable
private fun ToolsScreen(commands: List<SavedIrCommand>, send: (SavedIrCommand) -> Unit, remove: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("IR tools", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text("Saved commands can be tested here.")
        commands.forEach { c ->
            ElevatedCard {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(c.name); Text("${c.frequencyHz} Hz · ${c.pattern.size} timings", style = MaterialTheme.typography.bodySmall) }
                    IconButton(onClick = { send(c) }) { Icon(Icons.Default.Send, "Transmit") }
                    IconButton(onClick = { remove(c.name) }) { Icon(Icons.Default.Delete, "Delete") }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(status: String, available: Boolean, ranges: List<com.irfi.remote.core.ir.CarrierRange>,
                           profiles: List<String>, selected: String,
                           onSelect: (String) -> Unit, onAddProfile: (String) -> Result<Unit>,
                           onRefresh: () -> Unit, onSave: (String, Int, String) -> Result<Unit>) {
    var newProfile by remember { mutableStateOf("") }
    var commandName by remember { mutableStateOf("Power") }
    var frequency by remember { mutableStateOf("38000") }
    var pattern by remember { mutableStateOf("") }
    var feedback by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Text("Settings & IR diagnostics", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(if (available) "IR emitter detected" else "IR emitter not detected", fontWeight = FontWeight.Bold)
                        Text(status, style = MaterialTheme.typography.bodySmall)
                        ranges.forEach { Text("${it.minimumHz}–${it.maximumHz} Hz", style = MaterialTheme.typography.bodySmall) }
                        OutlinedButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, null); Text("Refresh hardware status") }
                    }
                }
            }
            item { Text("TV profiles", style = MaterialTheme.typography.titleLarge) }
            item {
                profiles.forEach { name ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected == name, { onSelect(name) })
                        Text(name)
                    }
                }
            }
            item { OutlinedTextField(newProfile, { newProfile = it }, Modifier.fillMaxWidth(), label = { Text("New TV profile name") }) }
            item {
                OutlinedButton(onClick = {
                    feedback = onAddProfile(newProfile).fold({ newProfile = ""; "Profile added." }, { it.message ?: "Could not add profile." })
                }) { Text("Add profile") }
            }
            item { Divider(); Text("IR code manager", style = MaterialTheme.typography.titleLarge) }
            item { Text("Enter a verified raw IR timing pattern. Values are microseconds separated by commas. Do not guess codes.") }
            item { OutlinedTextField(commandName, { commandName = it }, Modifier.fillMaxWidth(), label = { Text("Command name") }) }
            item {
                OutlinedTextField(frequency, { frequency = it }, Modifier.fillMaxWidth(),
                    label = { Text("Carrier frequency (Hz)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            }
            item {
                OutlinedTextField(pattern, { pattern = it }, Modifier.fillMaxWidth(),
                    label = { Text("Raw timings, e.g. 9000,4500,560,560") }, minLines = 4)
            }
            item {
                Button(onClick = {
                    feedback = runCatching {
                        onSave(commandName, frequency.toInt(), pattern).getOrThrow()
                        "Saved command to $selected."
                    }.fold({ it }, { it.message ?: "Could not save command." })
                }, modifier = Modifier.fillMaxWidth()) { Text("Save IR command") }
            }
            item { if (feedback.isNotBlank()) Text(feedback, color = MaterialTheme.colorScheme.primary) }
            item { Text("Safety: transmitting an incorrect code may operate another nearby IR device. Test one command at a time.") }
        }
    }
}
