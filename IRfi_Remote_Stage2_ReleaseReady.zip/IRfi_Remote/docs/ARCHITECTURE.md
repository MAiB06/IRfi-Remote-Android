# Architecture

Stage 2 adds:
- `AndroidIrTransmitter`: ConsumerIrManager adapter and validation.
- `IrViewModel`: UI state, profile selection, command persistence and send results.
- `IrProfileStore`: SharedPreferences-backed local profile and command store.
- Compose screens for hardware diagnostics, profile management and raw code entry.

The store is intentionally small for this test stage. Migration to Room can be done when profile schema and macro requirements stabilize.
