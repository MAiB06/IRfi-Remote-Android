# Bluetooth investigation

Bluetooth HID is an optional compatibility path.

Before implementation, verify:
- Android phone API and role support for acting as a HID device.
- Whether the target TV accepts Bluetooth keyboard/mouse HID.
- Pairing requirements and user consent.
- Whether pointer movement is supported by the TV UI.

Do not label D-pad emulation as a real mouse pointer.
