# Build

The intended build path is GitHub Actions on GitHub-hosted Ubuntu runners.

The manual workflow:
- Builds a debug APK.
- Builds signed release APK/AAB only when all signing secrets are configured.
- Uploads available outputs as workflow artifacts.
- Publishes a GitHub Release only when explicitly selected and signed release outputs exist.

No local Termux or Android Studio installation is required for the user.
