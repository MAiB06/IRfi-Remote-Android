# IR command data and testing

Stage 2 stores raw timing arrays and carrier frequency per command and TV profile.

Each timing value is in microseconds. The pattern alternates mark/space durations as expected by Android ConsumerIrManager.

No device codes are preloaded because the exact retail TV model and protocol have not been established.

A saved command being transmitted successfully confirms only that Android accepted the request. Physical response from the intended TV is required to verify the code.
