# Wi-Fi compatibility investigation

The target television is reported to run Android-based software, system version 16, board/system identifier `hi3521`, and has no Google Play Services or Play Store.

This does not establish which remote-control service is installed.

Before implementing a Wi-Fi protocol:
1. Identify the TV's exact build fingerprint and available system services using user-authorized diagnostics.
2. Check for Android TV Remote Service or another documented remote endpoint.
3. Verify discovery, pairing, encryption and command support.
4. Test keyboard input independently from navigation.
5. Record unsupported capabilities honestly.

Do not assume Google TV support or require Google Play Services on the phone.
