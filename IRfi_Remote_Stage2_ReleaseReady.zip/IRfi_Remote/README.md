# IRfi Remote

## Stage 2 — IR engine and manual profile testing

This stage adds:
- Android `ConsumerIrManager` hardware detection.
- Carrier frequency range reporting.
- Validated raw IR transmission.
- Multiple local TV profiles.
- Persistent manually entered IR command patterns.
- Working transmit actions for saved commands.
- Hardware status and error feedback.

### Important limitations
- The phone's IR blaster is transmit-only unless separate receiver hardware is proven.
- No Elista/HomeTV IR codes are bundled because the exact TV models and verified codes are unknown.
- Add verified raw timings and a supported carrier frequency in Settings before testing.
- Wi-Fi keyboard, clipboard delivery, voice typing and mouse control are not part of Stage 2.

### Test plan
1. Install the debug APK on the OnePlus 15.
2. Open Home and confirm IR hardware status.
3. Open Settings and refresh hardware status.
4. Select or create a TV profile.
5. Enter a known-good raw IR code and frequency from the original remote's verified database or a trusted code source.
6. Save it and transmit once from Remote or Tools.
7. Confirm the TV responds; report the exact command, frequency and result.

Do not assume that a successful Android transmit call means the TV received or understood the code.
